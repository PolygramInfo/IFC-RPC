class ValidationError(ValueError):
    pass

class InvalidOperationError(RuntimeError):
    pass