from schema_builder import builder, factory, Model
import uuid

myBuilder = builder("myNewSchema")

myBuilder.add_definition("myDefinition", {"type": "string"})\
    .add_property("myFirstProperty", {"$ref": "#/definitions/myDefinition"})\
    .add_properties(
        mySecondProperty={"type": "string", "default": "value", "enum": ["value"]},
        myThirdProperty={"type": "string", "description": "description"}
    ).add_required("myFirstProperty", "mySecondProperty")\
    .allow_additional_properties()

print(myBuilder)

myFactory = myBuilder.factory("myNewSchema")

myInstance = myFactory(
    myFirstProperty="value", 
    mySecondProperty="value",
    myThirdProperty="value",
)

# Here is an example for components.

componentBuilder = builder("Component")

componentBuilder.add_definition(
    "IDDefinition", {"type": "string", "description": "The ID of the component."}
).add_properties(
    id={"$ref": "#/definitions/IDDefinition", "examples": [uuid.uuid4().hex]},
    description={"type": "string", "description": "The description of the component."},
    subcomponents={"type": "object", "description": "The subcomponents of the component."}
).add_required("id")

component_schema = str(componentBuilder)
print(component_schema)

# This will initialize a new component factory which is used to make instances
# of the component meta-schema.
componentFactory = componentBuilder.factory("Component")

dimensionBuilder = builder("Dimension").add_definition("DimensionDefinition", {"type": "number"})\
    .add_properties(
        width={"$ref": "#/definitions/DimensionDefinition", "description": "The width of the wall."},
        height={"$ref": "#/definitions/DimensionDefinition", "description": "The height of the wall."},
        length={"$ref": "#/definitions/DimensionDefinition", "description": "The length of the wall."}
    ).add_required("width", "height", "length")

myWallSchema = componentFactory(
    id=uuid.uuid4().hex,
    description="A wall is a component that is used to separate rooms.",
    subcomponents={
        "dimensions": dimensionBuilder.__dict__["schema"]
    }
)

print(myWallSchema)